"""Keep background sounds and background PEOPLE out of what the agent hears.

Two layers, both on the candidate's audio before speech recognition (Sarvam) gets it:

1. Voice gate (free, built in, on by default): the candidate talks right into the phone, so their
   voice is much louder than a TV, people talking across the room or traffic. The gate learns how
   loud the candidate's own voice is on this call and mutes anything much quieter than that
   (audio.voice_gate_db below it, default 15 dB, about 1/6 as loud). Muted audio is silence for
   Sarvam: no junk words, no false interruptions. It can't separate someone standing right next to
   the candidate and talking just as loudly; layer 2 can.

2. Voice Focus (optional, paid, off by default): ai-coustics "Quail Voice Focus", an AI model that
   keeps the main speaker and suppresses other voices and noise. Needs an ai-coustics account and
   licence key (AIC_LICENSE_KEY in .env) and: pip install "pipecat-ai[aic]==1.12.0"

config/agent.yaml:

    audio:
      voice_gate: true          # layer 1
      voice_gate_db: 15         # mute what is this much quieter than the candidate (12 = stricter, 20 = gentler)
      voice_focus: false        # layer 2 (ai-coustics), needs the licence key
      voice_focus_model: "quail-vf-2.2-s-16khz"

The dashboard's live audio keeps the ORIGINAL sound. The call recording has the candidate's side as
Sarvam heard it (muted parts are silent), so you can check what the gate removed.
"""

from __future__ import annotations

import collections
import math

from loguru import logger

from app.config import settings


def _cfg() -> dict:
    return settings.get("audio") or {}


def gate_enabled() -> bool:
    return _cfg().get("voice_gate", True) is not False


def gate_db() -> float:
    try:
        return min(40.0, max(6.0, float(_cfg().get("voice_gate_db", 20))))
    except (TypeError, ValueError):
        return 20.0


class GateLogic:
    """The decision part, without Pipecat (so it can be tested on its own)."""

    FLOOR_DB = -55.0      # quieter than this is silence: never used to learn the voice level
    WINDOW = 750          # frames remembered for the voice level (~15 s of 20 ms frames)
    WARMUP = 40           # voiced frames needed before the gate starts muting (~0.8 s of speech)
    HOLD = 15             # frames kept open after a loud one (~300 ms: word endings aren't cut)
    RELEARN = 2250        # nothing as loud as the candidate for ~45 s: forget the level and learn it again

    def __init__(self, below_db: float = 15.0):
        self.below = below_db
        self.recent: collections.deque = collections.deque(maxlen=self.WINDOW)
        self.level = None
        self.hold = 0
        self.frames = self.muted = 0
        self._since_update = 0
        self._since_open = 0

    @staticmethod
    def frame_db(pcm: bytes) -> float:
        n = len(pcm) // 2
        if not n:
            return -120.0
        try:
            import numpy as np

            x = np.frombuffer(pcm[: n * 2], dtype=np.int16).astype(np.float32)
            rms = float(np.sqrt(np.mean(x * x)))
        except ImportError:  # pragma: no cover
            import array

            a = array.array("h", pcm[: n * 2])
            rms = math.sqrt(sum(v * v for v in a) / n)
        return 20 * math.log10(rms / 32768.0 + 1e-9)

    def _update_level(self):
        loud = sorted(self.recent)
        self.level = loud[int(0.9 * (len(loud) - 1))]  # the candidate's normal speaking loudness

    def keep(self, db: float) -> bool:
        """True = pass this frame to speech recognition; False = replace it with silence."""
        self.frames += 1
        if self.level is not None and self._since_open >= self.RELEARN:
            self.level, self._since_open = None, 0  # (a quieter phone, a new speaker position...)
            self.recent.clear()
        # Learn only from sounds that could be the candidate: muted background never pulls the level down.
        if db > self.FLOOR_DB and (self.level is None or db >= self.level - self.below):
            self.recent.append(db)
            self._since_update += 1
            if len(self.recent) >= self.WARMUP and (self.level is None or self._since_update >= 25):
                self._update_level()
                self._since_update = 0
        if self.level is None:
            return True  # still learning the candidate's voice: let everything through
        if db >= self.level - self.below:
            self.hold, self._since_open = self.HOLD, 0
            return True
        self._since_open += 1
        if self.hold > 0:
            self.hold -= 1
            return True
        self.muted += 1
        return False

    def report(self) -> dict:
        return {"voice_level_db": round(self.level, 1) if self.level is not None else None,
                "gate_db": self.below, "muted_pct": round(100 * self.muted / self.frames, 1) if self.frames else 0}


def make_voice_gate(label: str = ""):
    """FrameProcessor: put it between the caller's audio and speech-to-text."""
    from pipecat.frames.frames import InputAudioRawFrame
    from pipecat.processors.frame_processor import FrameDirection, FrameProcessor

    from pipecat.frames.frames import CancelFrame, EndFrame

    class VoiceGate(FrameProcessor):
        """Audio is held back LOOKAHEAD frames (~80 ms), so the gate opens just BEFORE a word starts:
        the soft first sound of a word ("s", "f", "th", "h") is never cut off."""

        LOOKAHEAD = 4

        def __init__(self):
            super().__init__()
            self.logic = GateLogic(gate_db())
            self._pending: collections.deque = collections.deque()

        async def _release(self, direction):
            frame, _db = self._pending.popleft()
            try:
                ahead = max(d for _f, d in self._pending) if self._pending else -120.0
                if not self.logic.keep(max(_db, ahead)):
                    frame.audio = b"\0" * len(frame.audio)  # quiet background: silence for Sarvam
            except Exception:  # noqa: BLE001  the gate must never break a call
                pass
            await self.push_frame(frame, direction)

        async def process_frame(self, frame, direction: FrameDirection):
            await super().process_frame(frame, direction)
            if isinstance(frame, InputAudioRawFrame) and direction == FrameDirection.DOWNSTREAM:
                try:
                    db = GateLogic.frame_db(frame.audio)
                except Exception:  # noqa: BLE001
                    db = 0.0
                self._pending.append((frame, db))
                if len(self._pending) > self.LOOKAHEAD:
                    await self._release(direction)
                return
            if isinstance(frame, (EndFrame, CancelFrame)):
                while self._pending:
                    await self._release(FrameDirection.DOWNSTREAM)
            await self.push_frame(frame, direction)

    return VoiceGate()


def voice_focus_filter(label: str = ""):
    """ai-coustics Voice Focus as the transport's input filter, or None (off, or not set up).
    Never stops a call: if anything is missing it logs why and the call runs without it."""
    c = _cfg()
    if not c.get("voice_focus"):
        return None
    import os

    key = os.getenv("AIC_LICENSE_KEY", "").strip()
    if not key:
        logger.warning(f"[{label}] audio.voice_focus is on but AIC_LICENSE_KEY is not in .env: running without it")
        return None
    try:
        from pipecat.audio.filters.aic_filter import AICFilter
    except Exception as e:  # noqa: BLE001
        logger.warning(f"[{label}] Voice Focus not installed ({e}): pip install \"pipecat-ai[aic]==1.12.0\"")
        return None
    try:
        return AICFilter(license_key=key, model_id=str(c.get("voice_focus_model") or "quail-vf-2.2-s-16khz"))
    except Exception as e:  # noqa: BLE001
        logger.warning(f"[{label}] Voice Focus could not start ({e}): running without it")
        return None
